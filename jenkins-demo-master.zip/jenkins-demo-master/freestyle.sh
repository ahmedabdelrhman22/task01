npm --version
